﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace NeutronReplica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void vedooCustomButton1_Click(object sender, EventArgs e)
        {
            string tempFolderPath = Path.GetTempPath(); //Get the Temp folder path
            string downloadUrl = "https://github.com/NEXOS123/NeutronInjector/raw/main/NeutronInjectionManager.exe"; //Here is the Download location of NIM
            string downloadFilePath = Path.Combine(tempFolderPath, "NeutronOutput.exe"); //DO NOT EDIT THIS IF YOU DON'T KNOW WHAT TO DO!!!!
            string applicationPath = tempFolderPath + "NeutronOutput.exe"; //SAME AS ABOVE, DO NOT EDIT

            if (File.Exists(applicationPath)) //We check if we need to download NIM again
            {
                //===============================
                //This is checking if CSGO is running to exclude the risk of NIM error
                Process[] csgoProcesses = Process.GetProcessesByName("csgo");
                if (csgoProcesses.Length > 0) //CSGO is running
                {
                    lblStatus.ForeColor = this.ForeColor;
                    lblStatus.Text = "Starting Injection...";

                    ProcessStartInfo startInfo = new ProcessStartInfo(); // Start call the Process
                    startInfo.FileName = applicationPath; // NIM location
                    startInfo.Verb = "runas"; // Start NIM as administrator


                    lblStatus.Text = "Injection Dialog started.";
                    Process.Start(startInfo); // Start NIM
                }
                else // CSGO is not running
                {
                    lblStatus.ForeColor = Color.DarkRed;
                    lblStatus.Text = "No csgo.exe process found.";
                }
                //===============================


            }
            else
            {
                try //Try to download NIM
                {
                    lblStatus.ForeColor = this.ForeColor;


                    lblStatus.Text = "Downloading resorces...";

                    WebClient webClient = new WebClient(); // We need to call WebClient
                    webClient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ProgressChangedNIM); // You can use this witha  ProgressBar
                    webClient.DownloadFileCompleted += new AsyncCompletedEventHandler(CompletedNIM); // We need this to tell the user that the download was completed
                    webClient.DownloadFile(downloadUrl, downloadFilePath); // Download the File



                    //===============================
                    //This is checking if CSGO is running to exclude the risk of NIM error 
                    Process[] csgoProcesses = Process.GetProcessesByName("csgo");
                    if (csgoProcesses.Length > 0) //CSGO is running
                    {
                        ProcessStartInfo startInfo = new ProcessStartInfo(); // Start call the Process
                        startInfo.FileName = applicationPath; // NIM location
                        startInfo.Verb = "runas"; // Start NIM as administrator


                        lblStatus.Text = "Injection Dialog started.";
                        Process.Start(startInfo); // Start NIM
                    }
                    else // CSGO is not running
                    {
                        lblStatus.ForeColor = Color.DarkRed;
                        lblStatus.Text = "No csgo.exe process found.";
                    }
                    //===============================

                }
                catch (Exception ex) // Call the fail of the Download without crashing
                {
                    lblStatus.ForeColor = Color.DarkRed;
                    lblStatus.Text = "Injection/resorce error.";
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ProgressChangedNIM(object sender, DownloadProgressChangedEventArgs e)
        {
            lblStatus.Text = "Downloading Neutron Injection Manager..."; // Update the status label
        }

        private void CompletedNIM(object sender, AsyncCompletedEventArgs e)
        {
            // Download is complete!
            lblStatus.Text = "Download complete!";
            MessageBox.Show("Download for Neutron Injection Manager is complete!", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
