﻿namespace NeutronReplica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBrowseDLL = new VedooControls.VedooCustomButton();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBrowseDLL
            // 
            this.btnBrowseDLL.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnBrowseDLL.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btnBrowseDLL.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btnBrowseDLL.BorderRadius = 20;
            this.btnBrowseDLL.BorderSize = 0;
            this.btnBrowseDLL.FlatAppearance.BorderSize = 0;
            this.btnBrowseDLL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowseDLL.ForeColor = System.Drawing.Color.White;
            this.btnBrowseDLL.Location = new System.Drawing.Point(12, 12);
            this.btnBrowseDLL.Name = "btnBrowseDLL";
            this.btnBrowseDLL.Size = new System.Drawing.Size(150, 40);
            this.btnBrowseDLL.TabIndex = 0;
            this.btnBrowseDLL.Text = "Browse DLL";
            this.btnBrowseDLL.TextColor = System.Drawing.Color.White;
            this.btnBrowseDLL.UseVisualStyleBackColor = false;
            this.btnBrowseDLL.Click += new System.EventHandler(this.vedooCustomButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Status:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(59, 59);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(33, 13);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Text = "None";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBrowseDLL);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private VedooControls.VedooCustomButton btnBrowseDLL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStatus;
    }
}

